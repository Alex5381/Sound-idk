﻿using UnityEngine;

namespace StupidTemplate.Menu
{
    public class InputLibrary : MonoBehaviour
    {
        public static InputLibrary instance = new InputLibrary();
        public enum ButtonEnum
        {
            Trigger,
            Grip,
            Primary,
            Secondary,
        }
        public enum HandEnum
        {
            RightHand,
            LeftHand
        }
        public enum VREnum
        {
            OVR,
            Steam
        }
        public bool GetBtn(ButtonEnum btn, HandEnum hand, VREnum Platform)
        {
            bool Steam = false;
            if (Platform == VREnum.OVR)
            {
                Steam = false;
            }
            if (Platform == VREnum.Steam)
            {
                Steam = true;
            }
            if (Steam)
            {
                switch (hand)
                {
                    case HandEnum.RightHand:
                        switch (btn)
                        {
                            case ButtonEnum.Trigger: return ControllerInputPoller.instance.rightControllerIndexFloat >= 0.4f;
                            case ButtonEnum.Grip: return ControllerInputPoller.instance.rightControllerGripFloat == 1f;
                            case ButtonEnum.Primary: return ControllerInputPoller.instance.rightControllerPrimaryButton;
                            case ButtonEnum.Secondary: return ControllerInputPoller.instance.rightControllerSecondaryButton;
                        }
                        break;
                    case HandEnum.LeftHand:
                        switch (btn)
                        {
                            case ButtonEnum.Trigger: return ControllerInputPoller.instance.leftControllerIndexFloat >= 0.4f;
                            case ButtonEnum.Grip: return ControllerInputPoller.instance.leftControllerGripFloat == 1f;
                            case ButtonEnum.Primary: return ControllerInputPoller.instance.leftControllerPrimaryButton;
                            case ButtonEnum.Secondary: return ControllerInputPoller.instance.leftControllerSecondaryButton;
                        }
                        break;
                }
            }
            else
            {
                switch (hand)
                {
                    case HandEnum.RightHand:
                        switch (btn)
                        {
                            case ButtonEnum.Trigger: return ControllerInputPoller.instance.rightControllerIndexFloat >= 0.4f;
                            case ButtonEnum.Grip: return ControllerInputPoller.instance.rightControllerGripFloat == 1f;
                            case ButtonEnum.Primary: return ControllerInputPoller.instance.rightControllerSecondaryButton;
                            case ButtonEnum.Secondary: return ControllerInputPoller.instance.rightControllerPrimaryButton;
                        }
                        break;
                    case HandEnum.LeftHand:
                        switch (btn)
                        {
                            case ButtonEnum.Trigger: return ControllerInputPoller.instance.leftControllerIndexFloat >= 0.4f;
                            case ButtonEnum.Grip: return ControllerInputPoller.instance.leftControllerGripFloat == 1f;
                            case ButtonEnum.Primary: return ControllerInputPoller.instance.leftControllerSecondaryButton;
                            case ButtonEnum.Secondary: return ControllerInputPoller.instance.leftControllerPrimaryButton;
                        }
                        break;
                }
            }
            return false;
        }
    }
}

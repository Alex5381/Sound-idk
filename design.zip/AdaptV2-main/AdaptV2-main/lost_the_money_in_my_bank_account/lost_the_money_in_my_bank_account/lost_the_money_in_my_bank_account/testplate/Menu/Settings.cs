﻿using StupidTemplate.Classes;
using UnityEngine;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate
{
    internal class Settings
    {
        // style shit
        public static ExtGradient backgroundColor = new ExtGradient { colors = GetSolidGradient(new Color(0.102f, 0.102f, 0.102f)) };
        public static ExtGradient backgroundbColor = new ExtGradient { colors = GetSolidGradient(new Color(0.577f, 0.00840f, 0.840f)) };

        public static ExtGradient[] buttonColors = new ExtGradient[]
        {
    new ExtGradient{colors = GetSolidGradient(new Color(0.149f, 0.149f, 0.149f))}, // Disabled
    new ExtGradient{colors = GetSolidGradient(new Color(0.62f, 0.329f, 0.447f))} // Enabled
        };
        public static Color[] textColors = new Color[]
        {
    new Color(0.78f, 0.78f, 0.78f),
    Color.white // Enabled
        };

        public static Font currentFont = Font.CreateDynamicFontFromOSFont("MS Gothic", 16);
        //REMBNSATN

        public static bool fpsCounter = true;
        public static bool disconnectButton = false;
        public static bool watermark = true;
        public static bool rightHanded = false;
        public static bool functionlist = true;
        public static bool disableNotifications = false;

        public static KeyCode keyboardButton = KeyCode.Q; // now f15 since this will only be used as a backup gui

        public static Vector3 menuSize = new Vector3(0.01f, 1f, 0.7f); // Depth, Width, Height
        public static Vector3 menutbSize = new Vector3(0.01f, 1f, 0.04f); // Depth, Width, Height
        public static Vector3 menuoSize = new Vector3(0.009f, 1.01f, 0.71f); // Depth, Width, Height
        public static Vector3 menuBSize = new Vector3(0.008f, 1.03f, 0.72f); // Depth, Width, Height
        public static int buttonsPerPage = 6;
    }
}
